<?php


function prrecipe_widgets_init(){

    register_widget( 'PRRECIPE_Daily_Recipe_Widget' );

}