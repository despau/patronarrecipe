<?php


function prrecipe_dismiss_pending_recipe_notice(){

    update_option( 'prrecipe_pending_recipe_notice', 0 );

}